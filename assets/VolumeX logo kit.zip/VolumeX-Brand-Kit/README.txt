VolumeX brand kit

icon/VolumeX.ico        App / .exe icon. 15 sizes, 16-256 px (small sizes pixel-tuned).
                        WinForms/WPF: <ApplicationIcon>icon\VolumeX.ico</ApplicationIcon> in the .csproj.
                        Win32/C++: IDI_APPICON ICON "VolumeX.ico" in the .rc file.
icon/VolumeX-icon.svg   Vector master of the app icon.
icon/png/               Transparent PNGs, 16-1024 px (installer, website, store listings).
tray/                   System tray icons: -dark-taskbar (white glyph), -light-taskbar (dark glyph).
logo/                   Horizontal logo + wordmark. "-reversed" = for dark backgrounds.
msix/                   Visual assets for an MSIX / Microsoft Store package. Copy into the
                        project's Assets folder; names match Package.appxmanifest defaults.

Colors
  Signal Orange  #FF5A1F
  Ink            #16110E
  Bone           #F4EFE7

Clear space around the logo: at least half the icon height on every side.
Minimum logo width: 120 px on screen.